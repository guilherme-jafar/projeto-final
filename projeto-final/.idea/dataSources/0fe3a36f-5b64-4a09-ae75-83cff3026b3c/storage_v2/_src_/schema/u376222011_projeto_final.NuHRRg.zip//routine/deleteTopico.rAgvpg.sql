create
    definer = u376222011_projetofinal@`%` procedure deleteTopico(IN id_topico varchar(255))
BEGIN

Delete FROM multimedia WHERE perguntas_id IN (SELECT id FROM perguntas WHERE topicos_id = id_topico);																												
Delete  FROM respostas_quizz WHERE pergunta_id IN (SELECT id FROM perguntas WHERE topicos_id = id_topico);
DELETE FROM pergunta_quizz WHERE topico_id = id_topico;													
DELETE FROM respostas WHERE perguntas_id IN  (SELECT id FROM perguntas WHERE topicos_id = id_topico );
DELETE  FROM perguntas WHERE topicos_id = id_topico;
DELETE FROM topicos WHERE id = id_topico;
END;


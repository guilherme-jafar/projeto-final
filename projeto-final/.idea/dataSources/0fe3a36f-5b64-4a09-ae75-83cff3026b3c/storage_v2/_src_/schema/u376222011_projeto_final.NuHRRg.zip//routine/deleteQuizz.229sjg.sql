create
    definer = u376222011_projetofinal@`%` procedure deleteQuizz(IN id_quizz varchar(255))
BEGIN
DELETE FROM respostas_quizz WHERE sessao_id IN (SELECT id FROM sessao WHERE quizz_id = id_quizz);
DELETE FROM topicos_quizz WHERE quizz_id = id_quizz;
DELETE FROM sessao WHERE quizz_id = id_quizz;																										
DELETE FROM pergunta_quizz WHERE quizz_id = id_quizz;													
DELETE FROM quizz WHERE id = id_quizz;
END;


create
    definer = u376222011_projetofinal@`%` procedure deleteDisciplina(IN id_disciplina varchar(255))
BEGIN

	

	if EXISTS (SELECT * FROM disciplina_aluno WHERE disciplina_id = id_disciplina) then  
			DELETE FROM disciplina_aluno WHERE disciplina_id = id_disciplina;
	END if;
	

	
	DELETE FROM prof__disciplina WHERE disciplina_id = id_disciplina;
	DELETE FROM disciplina WHERE id = id_disciplina;
END;


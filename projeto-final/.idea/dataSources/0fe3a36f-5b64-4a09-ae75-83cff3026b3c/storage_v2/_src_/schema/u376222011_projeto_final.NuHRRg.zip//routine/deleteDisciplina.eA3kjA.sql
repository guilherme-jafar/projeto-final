create
    definer = u376222011_projetofinal@`%` procedure deleteDisciplina(IN id_disciplina varchar(255))
BEGIN
DELETE FROM mensagem WHERE forum_id IN (SELECT id FROM forum WHERE disciplina_id = id_disciplina );
DELETE FROM forum WHERE disciplina_id = id_disciplina;
DELETE FROM topicos_quizz WHERE quizz_id IN (SELECT id FROM quizz	WHERE disciplina_id = id_disciplina ); 
Delete FROM multimedia WHERE perguntas_id IN (SELECT id FROM perguntas WHERE topicos_id IN (SELECT id FROM topicos WHERE disciplina_id = id_disciplina ));																												
Delete  FROM respostas_quizz WHERE pergunta_id IN  (SELECT id FROM perguntas WHERE topicos_id IN (SELECT id FROM topicos WHERE disciplina_id = id_disciplina ) );
DELETE FROM pergunta_quizz WHERE topico_id IN (SELECT id FROM topicos WHERE disciplina_id = id_disciplina);													
DELETE FROM respostas WHERE perguntas_id IN  (SELECT id FROM perguntas WHERE topicos_id IN (SELECT id FROM topicos	WHERE disciplina_id = id_disciplina ) );
DELETE  FROM perguntas WHERE topicos_id IN (SELECT id FROM topicos WHERE disciplina_id = id_disciplina );
DELETE FROM disciplina_aluno WHERE disciplina_id = id_disciplina;
DELETE FROM historico WHERE disciplina_id = id_disciplina;
DELETE FROM topicos WHERE disciplina_id = id_disciplina;
DELETE FROM quizz WHERE disciplina_id = id_disciplina;
DELETE FROM prof__disciplina WHERE disciplina_id = id_disciplina;
DELETE FROM disciplina WHERE id = id_disciplina;
END;


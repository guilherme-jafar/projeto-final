create
    definer = u376222011_projetofinal@`%` procedure inProf(IN ntoken varchar(512))
BEGIN
	
	INSERT INTO utilizador(id,nome,email,PASSWORD,tipo,sexo) 
SELECT id,nome,email,PASSWORD,tipo,sexo
FROM utilizador_nao_confirmado
WHERE token = ntoken;
COMMIT;
DELETE FROM utilizador_nao_confirmado
WHERE token=ntoken;
COMMIT;
END;


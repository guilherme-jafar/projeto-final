create
    definer = u376222011_projetofinal@`%` procedure deletePergunta(IN id_perguntas varchar(255))
BEGIN
Delete FROM multimedia
WHERE perguntas_id = id_perguntas;
DELETE FROM respostas
WHERE perguntas_id  = id_perguntas;
DELETE FROM perguntas WHERE id = id_perguntas;
END;


<?php $__env->startSection('content2'); ?>

<div id="app">
<wait-room  :sessao_prop="'<?php echo e(json_encode($session, TRUE)); ?>'"  ></wait-room>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/layoutPergunta2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\projeto final\projeto-final\projeto-final\resources\views//quizz/WaitRoom.blade.php ENDPATH**/ ?>
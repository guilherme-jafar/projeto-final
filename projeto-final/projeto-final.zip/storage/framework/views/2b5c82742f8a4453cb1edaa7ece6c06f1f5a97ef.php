

<?php $__env->startSection('content'); ?>

    <div class="col-md-8 mx-auto">
        <div id="app" >

            <?php if(session('estado')): ?>
                <div class="alert alert-primary alert-dismissible fade show mb-5" role="alert" id="alert">
                    <strong><i class="bi bi-check-circle-fill"></i> &nbsp;&nbsp;Perfil alterado com sucesso</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>



            <div>

                <dashboard class="dashboard section-dashboard" :disciplinas_prop="'<?php echo e(json_encode($disciplinas, TRUE)); ?>'"></dashboard>

            </div>
        </div>
    </div>

<script >

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\projeto final\projeto-final\projeto-final\resources\views//prof/dashboard.blade.php ENDPATH**/ ?>
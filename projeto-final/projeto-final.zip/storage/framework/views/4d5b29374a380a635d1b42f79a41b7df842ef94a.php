

<?php $__env->startSection('content'); ?>

    <div class="col-md-12 mx-auto">
        <div id="app" >








            <pergunta-editar  class="dashboard section-dashboard" :pergunta_prop="'<?php echo e(json_encode($pergunta, TRUE)); ?>'"  ></pergunta-editar>


        </div>
    </div>

    <script >

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\projeto final\projeto-final\projeto-final\resources\views//prof/pergunta.blade.php ENDPATH**/ ?>
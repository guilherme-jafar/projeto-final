


<?php $__env->startSection('content'); ?>


    <div class="text-center card p-5">
        <h2>Parabens <?php echo e(session('utilizador')['nome']); ?></h2>

        <h2>Acabou o quizz <?php echo e($nome); ?> com <?php echo e($res); ?> pontos</h2>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\projeto final\projeto-final\projeto-final\resources\views//quizz/EndQuizz.blade.php ENDPATH**/ ?>
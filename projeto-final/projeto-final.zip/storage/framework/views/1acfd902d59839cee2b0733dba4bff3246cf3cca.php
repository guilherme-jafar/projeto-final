

<?php $__env->startSection('content'); ?>

    <div class="col-md-6 mx-auto">
        <div id="app" >
            <div>

                <editar-perfil class="section-editarPerfil" :utilizador_props="'<?php echo e(json_encode(session('utilizador'), TRUE)); ?>'" ></editar-perfil>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\projeto final\projeto-final\projeto-final\resources\views//autenticacao/editarPerfil.blade.php ENDPATH**/ ?>
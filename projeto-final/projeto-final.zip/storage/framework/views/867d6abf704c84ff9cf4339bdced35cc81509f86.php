<!DOCTYPE html>
<html>
<head>
    <title>Page Not Found</title>
</head>
<body>
 500 error page.
</body>
</html>
<?php /**PATH C:\Apache24\htdocs\projeto final\projeto-final\projeto-final\resources\views/errors/400Error.blade.php ENDPATH**/ ?>

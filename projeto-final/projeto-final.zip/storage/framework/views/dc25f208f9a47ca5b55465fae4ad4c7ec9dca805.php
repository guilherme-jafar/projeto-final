<?php echo e($slot); ?>

<?php /**PATH C:\Apache24\htdocs\projeto final\projeto-final\projeto-final\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
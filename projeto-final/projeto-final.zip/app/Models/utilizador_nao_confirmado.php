<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class utilizador_nao_confirmado extends Model
{
    protected $table = 'utilizador_nao_confirmado';
    use HasFactory;
}
